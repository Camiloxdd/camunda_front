-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: requisiciones
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items_formulario`
--

DROP TABLE IF EXISTS `items_formulario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items_formulario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formulario_id` int DEFAULT NULL,
  `descripcion` text,
  `cantidad` int DEFAULT NULL,
  `centro` varchar(255) DEFAULT NULL,
  `cuenta` varchar(255) DEFAULT NULL,
  `valor` decimal(15,2) DEFAULT NULL,
  `vobo` tinyint DEFAULT NULL,
  `productoOServicio` varchar(255) DEFAULT NULL,
  `purchaseAprobated` tinyint DEFAULT NULL,
  `siExiste` tinyint DEFAULT NULL,
  `sstAprobacion` tinyint DEFAULT NULL,
  `aprobatedStatus` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `formulario_id` (`formulario_id`),
  CONSTRAINT `items_formulario_ibfk_1` FOREIGN KEY (`formulario_id`) REFERENCES `formularios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items_formulario`
--

LOCK TABLES `items_formulario` WRITE;
/*!40000 ALTER TABLE `items_formulario` DISABLE KEYS */;
INSERT INTO `items_formulario` VALUES (49,14,'PC para trabajo',1,'999','87546',7500000.00,1,NULL,NULL,NULL,NULL,NULL),(50,14,'Silla para trabajador',1,'999','84579',25000000.00,0,NULL,NULL,NULL,NULL,NULL),(51,14,'Mouse para trabajo',1,'999','28234',700000.00,1,NULL,NULL,NULL,NULL,NULL),(58,15,'PC para trabajador',1,'854','98645',7500000.00,0,NULL,NULL,NULL,NULL,NULL),(59,15,'pantalla para trabajador',1,'652','53154',15000000.00,0,NULL,NULL,NULL,NULL,NULL),(60,15,'Mouse para trabajador',1,'685','75689',120000.00,0,NULL,NULL,NULL,NULL,NULL),(65,17,'asd',1,'788754','4567',500000.00,0,NULL,NULL,NULL,NULL,NULL),(66,17,'asd',1,'4564','14231',500000.00,0,NULL,NULL,NULL,NULL,NULL),(67,16,'asd',1,'8569','254136',800000.00,0,NULL,NULL,NULL,NULL,NULL),(68,16,'asd',1,'9874','589647',2500000.00,1,NULL,NULL,NULL,NULL,NULL),(69,18,'sad',1,'45123','45234',15000000.00,1,'PC',0,0,0,NULL),(70,18,'asd',1,'4563453','123123',25000000.00,0,'Silla',1,1,1,NULL),(71,19,'asd',1,'7878','7878',1500000.00,1,'PC',0,0,0,0),(72,19,'asd',1,'7878','7878',2500000.00,0,'Silla',1,1,1,0),(73,20,'tester',1,'7845','9865',5000000.00,1,'PC',0,0,0,1),(74,20,'tester',1,'8754','5689',15000000.00,0,'Silla',1,1,1,0),(75,21,'tester',1,'tester','tester',100000.00,0,'tester',1,1,1,0),(76,22,'tester',1,'tester','tester',1800000.00,1,'tester',0,0,0,0),(77,22,'tester',1,'tester','tester',15000000.00,0,'tester',1,1,1,0),(78,23,'tester',1,'tester','tester',1800000.00,1,'tester',0,0,0,1),(79,24,'tester',1,'tester','tester',1800000.00,1,'tester',0,0,0,1),(80,25,'tester',1,'87456','87456',1800000.00,1,'PC',0,0,0,1),(81,25,'tester',1,'87456','87456',25000000.00,0,'Silla',1,1,0,0),(82,25,'tester',1,'87456','87456',700000.00,0,'Mouse',0,0,0,0),(83,25,'tester',1,'87456','87456',1950000.00,0,'Apoya Pies',1,1,0,0),(84,26,'tester',1,'tester','tester',1500000.00,0,'tester',1,1,0,1),(85,26,'tester',1,'tester','tester',1500000.00,1,'tester',0,0,0,1),(86,26,'tester',1,'tester','tester',1500000.00,0,'tester',1,1,1,1),(87,26,'tester',1,'tester','tester',1500000.00,0,'tester',0,0,0,1);
/*!40000 ALTER TABLE `items_formulario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-20 15:49:14
