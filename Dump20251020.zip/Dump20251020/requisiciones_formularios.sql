-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: requisiciones
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `formularios`
--

DROP TABLE IF EXISTS `formularios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formularios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `fechaSolicitud` date DEFAULT NULL,
  `fechaEntrega` date DEFAULT NULL,
  `justificacion` text,
  `area` varchar(255) DEFAULT NULL,
  `sede` varchar(255) DEFAULT NULL,
  `urgenciaCompra` varchar(100) DEFAULT NULL,
  `tiempoGestion` varchar(100) DEFAULT NULL,
  `anexos` text,
  `nombreSolicitante` varchar(255) DEFAULT NULL,
  `firmaSolicitante` varchar(255) DEFAULT NULL,
  `nombreAdministrativo` varchar(255) DEFAULT NULL,
  `firmaAdministrativo` varchar(255) DEFAULT NULL,
  `nombreGerente` varchar(255) DEFAULT NULL,
  `firmaGerente` varchar(255) DEFAULT NULL,
  `autorizacionGerencia` varchar(255) DEFAULT NULL,
  `firmaCompras` varchar(255) DEFAULT NULL,
  `creadoEn` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formularios`
--

LOCK TABLES `formularios` WRITE;
/*!40000 ALTER TABLE `formularios` DISABLE KEYS */;
INSERT INTO `formularios` VALUES (14,'tester','2025-10-06','2025-10-07','tester','tester','tester','tester','tester','tester','Camilo Bello','Camilo Bello','fulanito','tester','Kenneth Campos','Kenneth Campos','tester','tester','2025-10-06 15:59:24'),(15,'Juan Camilo Bello Roa','2025-10-06','2025-10-08','Compra de equipo para trabajador nuevo','Tecnologia y Proyectos','Principal','Alta','15 minutos','Si','Kenneth Campos','Kenneth Campos','Wilson Marulanda','Wilson Marulanda','Wilson Marulanda','Wilson Marulanda','Camilo Bello','Wilson Marulanda','2025-10-06 16:48:28'),(16,'Juan Camilo Bello Roa','2025-10-06','2025-10-09','Compra de equipo para trabajador nuevo','Tecnologia y Proyectos','Principal','Alta','15 minutos','Si','tester','tester','testertester','tester','','','','','2025-10-06 17:03:59'),(17,'Edison Kenneth Campos','2025-10-06','2025-10-06','Compra de equipo para trabajador nuevo','Tecnologia y Proyectos','Principal','Alta','15 minutos','Si','Kenneth Campos','Kenneth Campos','Kenneth Campos','Kenneth Campos','','','','','2025-10-06 17:10:11'),(18,'Juan Camilo Bello Roa','2025-10-06','2025-10-07','Compra de equipo para trabajador nuevo','Tecnologia y Proyectos','Principal','Alta','15 minutos','Si','asd','asd','asd','asd','asd','asd','asd','asd','2025-10-06 17:28:31'),(19,'Bello Roa Juan Camilo','2025-10-06','2025-10-06','Compra de equipo para trabajador nuevo','Tecnologia y Proyectos','Principal','Alta','15 minutos','Si','tester','tester','tester','tester','tester','tester','tester','tester','2025-10-06 19:08:25'),(20,'tester','2025-10-06','2025-10-06','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','2025-10-06 19:34:33'),(21,'tester','2025-10-06','2025-10-07','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','','','','','2025-10-06 20:23:05'),(22,'tester','2025-10-07','2025-10-07','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','2025-10-07 20:35:27'),(23,'tester','2025-10-08','2025-10-08','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','2025-10-08 12:54:43'),(24,'tester','2025-10-08','2025-10-08','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','2025-10-08 12:56:26'),(25,'tester','2025-10-08','2025-10-08','tester','tester','tester','tester','tester','tester','Kenneth Campos','Kenneth Campos','Kenneth Campos','Kenneth Campos','Kenneth Campos','Kenneth Campos','Kenneth Campos','Kenneth Campos','2025-10-08 13:51:05'),(26,'tester','2025-10-08','2025-10-08','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','tester','2025-10-08 14:00:17');
/*!40000 ALTER TABLE `formularios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-20 15:49:14
